<!DOCTYPE HTML>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title> Inicia Sesion </title>
</head>
<body>
    <form action="<?php echo base_url();?>index.php/Loginctr/login" method="post" style="text-align: center;margin-top: 20%;">
        <input type="text" name="username" placeholder="Usuario" style="margin: 10px 0px"/><br>
        <input type="password" name="password" placeholder="Contraseña" style="margin: 10px 0px"/><br>
        <input type="submit" / >
    </form>
</body>
</html>
















