<html>
<head>
    <title>Sistema de Egresados</title>
</head>
<body>
       <a href= <?php echo base_url()."index.php/Loginctr/logout" ?> > Cerrar sesion </a><br>

       <a href= <?php echo base_url()."index.php/Egresadoctr" ?> >Egresados</a><br>
       <a href= <?php echo base_url()."index.php/Estudioctr" ?> >Estudios</a>
</body>
</html>