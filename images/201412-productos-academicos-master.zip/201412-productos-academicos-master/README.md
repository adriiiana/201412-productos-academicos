###################
Sistema de Productos Acad&eacute;micos
###################

Pr&aacute;ctica de Programaci&oacute;n Web.

*******************
Server Requirements
*******************

-  PHP version 5.2.4 or newer.

